<?php

$usuario="root";
$contrasena="";
$servidor="localhost";
$basedatos="latrailera";

$conexion=mysqli_connect($servidor,$usuario,"",$basedatos)or die("No se ha podido conectar al servidor de Base de datos");


?>